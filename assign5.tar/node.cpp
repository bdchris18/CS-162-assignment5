#include <iostream>
#include "node.h"

Node::Node(int new_val){
    val = new_val;
}